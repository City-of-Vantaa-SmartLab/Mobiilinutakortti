export { RegisterJuniorDto } from './register.dto';
